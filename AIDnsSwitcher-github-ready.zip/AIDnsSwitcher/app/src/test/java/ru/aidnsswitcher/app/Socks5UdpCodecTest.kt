package ru.aidnsswitcher.app

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class Socks5UdpCodecTest {
    @Test fun parsesIpv4DnsDatagramAndBuildsMatchingResponse() {
        val dns = byteArrayOf(0x12, 0x34, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0)
        val request = byteArrayOf(
            0, 0, 0, 1, 8, 8, 8, 8, 0, 53
        ) + dns
        val parsed = Socks5UdpCodec.parse(request, request.size)
        assertNotNull(parsed)
        assertEquals("8.8.8.8", parsed!!.host)
        assertEquals(53, parsed.port)
        assertArrayEquals(dns, parsed.payload)
        val answer = dns.copyOf().also { it[2] = 0x81.toByte(); it[3] = 0x80.toByte() }
        val framed = Socks5UdpCodec.responseForRequest(parsed, answer)
        assertArrayEquals(request.copyOfRange(0, 10), framed.copyOfRange(0, 10))
        assertArrayEquals(answer, framed.copyOfRange(10, framed.size))
    }

    @Test fun parsesDomainAddressWithoutDuplicatingLengthPrefix() {
        val query = byteArrayOf(1, 2, 3)
        val frame = byteArrayOf(0, 0, 0, 3, 11) + "example.com".toByteArray() + byteArrayOf(0, 53) + query
        val parsed = Socks5UdpCodec.parse(frame, frame.size)
        assertNotNull(parsed)
        assertEquals("example.com", parsed!!.host)
        val answer = Socks5UdpCodec.responseForRequest(parsed, query)
        assertEquals(3, answer[3].toInt())
        assertEquals(11, answer[4].toInt() and 0xff)
        assertArrayEquals("example.com".toByteArray(), answer.copyOfRange(5, 16))
    }

    @Test fun rejectsFragmentsAndMalformedFrames() {
        assertEquals(null, Socks5UdpCodec.parse(byteArrayOf(0, 0, 1, 1, 1, 2, 3, 4, 0, 53, 1), 11))
        assertEquals(null, Socks5UdpCodec.parse(byteArrayOf(0, 0, 0, 9, 1, 2, 3), 7))
    }
}
