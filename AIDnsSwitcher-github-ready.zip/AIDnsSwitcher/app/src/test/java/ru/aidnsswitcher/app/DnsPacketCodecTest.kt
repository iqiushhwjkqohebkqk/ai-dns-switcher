package ru.aidnsswitcher.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DnsPacketCodecTest {
    private fun dnsQuery(): ByteArray = byteArrayOf(
        0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x07, 0x65, 0x78, 0x61, 0x6d, 0x70, 0x6c, 0x65,
        0x03, 0x63, 0x6f, 0x6d, 0x00, 0x00, 0x01, 0x00, 0x01
    )

    private fun ipv4UdpPacket(dns: ByteArray, destinationPort: Int = 53): ByteArray {
        val packet = ByteArray(20 + 8 + dns.size)
        packet[0] = 0x45
        packet[9] = 17
        packet[12] = 192.toByte(); packet[13] = 168.toByte(); packet[14] = 1; packet[15] = 20
        packet[16] = 10; packet[17] = 111; packet[18] = 0; packet[19] = 2
        packet[20] = 0x30; packet[21] = 0x39
        packet[22] = (destinationPort ushr 8).toByte(); packet[23] = destinationPort.toByte()
        val udpLength = 8 + dns.size
        packet[24] = (udpLength ushr 8).toByte(); packet[25] = udpLength.toByte()
        dns.copyInto(packet, 28)
        return packet
    }

    @Test
    fun parsesUdpDnsQueryAndPreservesAddressesAndPort() {
        val payload = dnsQuery()
        val query = DnsPacketCodec.parseUdpDnsQuery(ipv4UdpPacket(payload), 20 + 8 + payload.size)
        assertNotNull(query)
        assertEquals(12345, query!!.sourcePort)
        assertEquals("192.168.1.20", query.sourceAddress.joinToString(".") { (it.toInt() and 255).toString() })
        assertTrue(query.dnsPayload.contentEquals(payload))
    }

    @Test
    fun ignoresPacketsNotAddressedToDnsPort() {
        val payload = dnsQuery()
        assertNull(DnsPacketCodec.parseUdpDnsQuery(ipv4UdpPacket(payload, destinationPort = 443), 20 + 8 + payload.size))
    }

    @Test
    fun acceptsNoErrorAndNxDomainResponses() {
        val query = dnsQuery()
        val noError = query.copyOf().apply {
            this[2] = 0x81.toByte()
            this[3] = 0x80.toByte()
        }
        val nxDomain = query.copyOf().apply {
            this[2] = 0x81.toByte()
            this[3] = 0x83.toByte()
        }
        assertTrue(DnsPacketCodec.isAcceptableDnsResponse(query, noError))
        assertTrue(DnsPacketCodec.isAcceptableDnsResponse(query, nxDomain))
    }

    @Test
    fun rejectsServFailFromProviderSoNextProfileCanBeTried() {
        val query = dnsQuery()
        val servFail = DnsPacketCodec.makeServFail(query)!!
        assertTrue(!DnsPacketCodec.isAcceptableDnsResponse(query, servFail))
    }

    @Test
    fun buildsServFailResponse() {
        val response = DnsPacketCodec.makeServFail(dnsQuery())!!
        assertTrue((response[2].toInt() and 0x80) != 0) // QR
        assertEquals(2, response[3].toInt() and 0x0f)   // SERVFAIL
        assertEquals(0, response[6].toInt() or response[7].toInt()) // no answer records
    }
    @Test
    fun readsRcodeFromDnsResponse() {
        val query = dnsQuery()
        val noError = query.copyOf().apply { this[2] = 0x81.toByte(); this[3] = 0x80.toByte() }
        val nxDomain = query.copyOf().apply { this[2] = 0x81.toByte(); this[3] = 0x83.toByte() }
        assertEquals(0, DnsPacketCodec.responseCode(noError))
        assertEquals(3, DnsPacketCodec.responseCode(nxDomain))
        assertNull(DnsPacketCodec.responseCode(query))
    }

}
