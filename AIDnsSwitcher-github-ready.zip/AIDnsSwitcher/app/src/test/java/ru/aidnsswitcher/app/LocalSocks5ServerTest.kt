package ru.aidnsswitcher.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.io.Closeable
import kotlin.concurrent.thread

class LocalSocks5ServerTest {
    @Test
    fun authenticatedRelayHandlesTcpDnsAndUdp() {
        val tcpEcho = ServerSocket(0, 10, InetAddress.getByName("127.0.0.1"))
        val tcpThread = thread(isDaemon = true) {
            while (!tcpEcho.isClosed) runCatching {
                val socket = tcpEcho.accept()
                thread(isDaemon = true) {
                    socket.use { it.getInputStream().copyTo(it.getOutputStream()) }
                }
            }
        }
        val udpEcho = DatagramSocket(InetSocketAddress("127.0.0.1", 0))
        val udpThread = thread(isDaemon = true) {
            val buffer = ByteArray(2048)
            while (!udpEcho.isClosed) runCatching {
                val packet = DatagramPacket(buffer, buffer.size)
                udpEcho.receive(packet)
                udpEcho.send(DatagramPacket(packet.data, packet.length, packet.address, packet.port))
            }
        }

        val relay = LocalSocks5Server(
            protectSocket = { true },
            protectDatagram = { true },
            resolveDns = { query -> query.copyOf().also { it[2] = 0x81.toByte(); it[3] = 0x80.toByte() } },
            onFatalError = { throw it },
            username = "unit-user",
            password = "unit-pass",
            port = 0
        )

        try {
            relay.start()
            assertTrue("The OS should assign an ephemeral loopback port", relay.boundPort > 0)

            // Reject unauthenticated local clients.
            Socket("127.0.0.1", relay.boundPort).use { socket ->
                val input = DataInputStream(socket.getInputStream())
                val output = DataOutputStream(socket.getOutputStream())
                output.write(byteArrayOf(5, 1, 0)); output.flush()
                assertEquals(5, input.readUnsignedByte())
                assertEquals(0xff, input.readUnsignedByte())
            }

            // TCP CONNECT and bidirectional forwarding.
            socksClient(relay.boundPort).use { (socket, input, output) ->
                val port = tcpEcho.localPort
                output.write(byteArrayOf(5, 1, 0, 1, 127, 0, 0, 1,
                    (port ushr 8).toByte(), port.toByte()))
                output.flush()
                val reply = ByteArray(10); input.readFully(reply)
                assertEquals(0, reply[1].toInt())
                output.write("tcp-roundtrip".toByteArray()); output.flush()
                val echoed = ByteArray("tcp-roundtrip".length); input.readFully(echoed)
                assertEquals("tcp-roundtrip", echoed.toString(Charsets.UTF_8))
            }

            // TCP DNS requests use two-byte DNS-over-TCP framing and the DoH callback.
            socksClient(relay.boundPort).use { (_, input, output) ->
                output.write(byteArrayOf(5, 1, 0, 1, 8, 8, 8, 8, 0, 53)); output.flush()
                val reply = ByteArray(10); input.readFully(reply)
                assertEquals(0, reply[1].toInt())
                val query = dnsQuery(0x3344)
                output.writeShort(query.size); output.write(query); output.flush()
                val size = input.readUnsignedShort()
                val response = ByteArray(size); input.readFully(response)
                assertEquals(0x33, response[0].toInt() and 0xff)
                assertTrue((response[2].toInt() and 0x80) != 0)
            }

            // UDP ASSOCIATE: DNS is resolved by the callback; other UDP is relayed normally.
            Socket("127.0.0.1", relay.boundPort).use { control ->
                val (input, output) = authenticate(control)
                output.write(byteArrayOf(5, 3, 0, 1, 0, 0, 0, 0, 0, 0)); output.flush()
                val reply = ByteArray(10); input.readFully(reply)
                assertEquals(0, reply[1].toInt())
                val bindPort = ((reply[8].toInt() and 0xff) shl 8) or (reply[9].toInt() and 0xff)
                DatagramSocket().use { client ->
                    client.soTimeout = 3000
                    val query = dnsQuery(0x4455)
                    val dnsFrame = byteArrayOf(0, 0, 0, 1, 8, 8, 8, 8, 0, 53) + query
                    client.send(DatagramPacket(dnsFrame, dnsFrame.size,
                        InetAddress.getByName("127.0.0.1"), bindPort))
                    val data = ByteArray(1500)
                    val dnsPacket = DatagramPacket(data, data.size)
                    client.receive(dnsPacket)
                    val dnsResponse = requireNotNull(Socks5UdpCodec.parse(dnsPacket.data, dnsPacket.length))
                    assertEquals("8.8.8.8", dnsResponse.host)
                    assertTrue((dnsResponse.payload[2].toInt() and 0x80) != 0)

                    val echoPort = udpEcho.localPort
                    val payload = "udp-roundtrip".toByteArray()
                    val udpFrame = byteArrayOf(0, 0, 0, 1, 127, 0, 0, 1,
                        (echoPort ushr 8).toByte(), echoPort.toByte()) + payload
                    client.send(DatagramPacket(udpFrame, udpFrame.size,
                        InetAddress.getByName("127.0.0.1"), bindPort))
                    val udpPacket = DatagramPacket(ByteArray(1500), 1500)
                    client.receive(udpPacket)
                    val udpResponse = Socks5UdpCodec.parse(udpPacket.data, udpPacket.length)
                    assertEquals("udp-roundtrip", udpResponse?.payload?.toString(Charsets.UTF_8))
                }
            }
        } finally {
            relay.close()
            tcpEcho.close()
            udpEcho.close()
            tcpThread.interrupt()
            udpThread.interrupt()
        }
    }

    private data class SocksClient(
        val socket: Socket,
        val input: DataInputStream,
        val output: DataOutputStream
    ) : Closeable {
        override fun close() = socket.close()
    }

    private fun socksClient(port: Int): SocksClient {
        val socket = Socket("127.0.0.1", port)
        val (input, output) = authenticate(socket)
        return SocksClient(socket, input, output)
    }

    private fun authenticate(socket: Socket): Pair<DataInputStream, DataOutputStream> {
        socket.soTimeout = 3000
        val input = DataInputStream(socket.getInputStream())
        val output = DataOutputStream(socket.getOutputStream())
        output.write(byteArrayOf(5, 1, 2)); output.flush()
        assertEquals(5, input.readUnsignedByte())
        assertEquals(2, input.readUnsignedByte())
        val user = "unit-user".toByteArray()
        val pass = "unit-pass".toByteArray()
        output.write(byteArrayOf(1, user.size.toByte()) + user + byteArrayOf(pass.size.toByte()) + pass)
        output.flush()
        assertEquals(1, input.readUnsignedByte())
        assertEquals(0, input.readUnsignedByte())
        return input to output
    }

    private fun dnsQuery(id: Int): ByteArray = byteArrayOf(
        (id ushr 8).toByte(), id.toByte(), 0x01, 0x00,
        0, 1, 0, 0, 0, 0, 0, 0
    )
}
