package ru.aidnsswitcher.app

/** DNS packet validation and SERVFAIL helpers shared by the local DoH relay and tests. */
object DnsPacketCodec {
    data class Query(
        val sourceAddress: ByteArray,
        val destinationAddress: ByteArray,
        val sourcePort: Int,
        val dnsPayload: ByteArray
    )

    fun parseUdpDnsQuery(packet: ByteArray, length: Int): Query? {
        if (length < 20) return null
        val version = (packet[0].toInt() ushr 4) and 0x0f
        if (version != 4) return null
        val ipHeaderLength = (packet[0].toInt() and 0x0f) * 4
        if (ipHeaderLength < 20 || length < ipHeaderLength + 8) return null
        if ((packet[9].toInt() and 0xff) != 17) return null // UDP only

        val fragmentField = u16(packet, 6)
        if ((fragmentField and 0x1fff) != 0) return null // no fragmented packets

        val udpOffset = ipHeaderLength
        val destinationPort = u16(packet, udpOffset + 2)
        if (destinationPort != 53) return null
        val udpLength = u16(packet, udpOffset + 4)
        if (udpLength < 8 || udpOffset + udpLength > length) return null

        val dnsStart = udpOffset + 8
        val dnsLength = udpLength - 8
        if (dnsLength < 12) return null

        return Query(
            sourceAddress = packet.copyOfRange(12, 16),
            destinationAddress = packet.copyOfRange(16, 20),
            sourcePort = u16(packet, udpOffset),
            dnsPayload = packet.copyOfRange(dnsStart, dnsStart + dnsLength)
        )
    }

    fun buildUdpDnsResponse(query: Query, dnsResponse: ByteArray): ByteArray {
        val totalLength = 20 + 8 + dnsResponse.size
        require(totalLength <= 65535)
        val packet = ByteArray(totalLength)

        packet[0] = 0x45
        packet[1] = 0
        put16(packet, 2, totalLength)
        put16(packet, 4, 0)
        put16(packet, 6, 0x4000) // Don't fragment
        packet[8] = 64
        packet[9] = 17
        put16(packet, 10, 0)
        query.destinationAddress.copyInto(packet, 12) // source becomes virtual DNS server
        query.sourceAddress.copyInto(packet, 16)
        put16(packet, 10, checksum(packet, 0, 20))

        val udpOffset = 20
        put16(packet, udpOffset, 53)
        put16(packet, udpOffset + 2, query.sourcePort)
        put16(packet, udpOffset + 4, 8 + dnsResponse.size)
        put16(packet, udpOffset + 6, 0) // valid zero checksum for IPv4 UDP
        dnsResponse.copyInto(packet, udpOffset + 8)
        return packet
    }

    /** Return DNS RCODE for a syntactically valid response, or null for non-responses. */
    fun responseCode(response: ByteArray): Int? {
        if (response.size < 12) return null
        val flags = u16(response, 2)
        if ((flags and 0x8000) == 0) return null
        return flags and 0x000f
    }

    /** Accept successful responses and NXDOMAIN; transient RCODEs trigger profile fallback. */
    fun isAcceptableDnsResponse(query: ByteArray, response: ByteArray): Boolean {
        if (query.size < 12 || response.size !in 12..8192) return false
        if (response[0] != query[0] || response[1] != query[1]) return false
        val flags = u16(response, 2)
        if ((flags and 0x8000) == 0) return false // QR must identify a response
        val rcode = flags and 0x000f
        return rcode == 0 || rcode == 3 // NOERROR or NXDOMAIN
    }

    fun makeServFail(query: ByteArray): ByteArray? {
        if (query.size < 12) return null
        val response = query.copyOf()
        val oldFlags = u16(response, 2)
        val opcodeAndRd = oldFlags and (0x7800 or 0x0100)
        val flags = 0x8000 or opcodeAndRd or 0x0080 or 0x0002 // QR, RA, SERVFAIL
        put16(response, 2, flags)
        put16(response, 6, 0)  // ANCOUNT
        put16(response, 8, 0)  // NSCOUNT
        put16(response, 10, 0) // ARCOUNT
        return response
    }

    private fun u16(data: ByteArray, offset: Int): Int =
        ((data[offset].toInt() and 0xff) shl 8) or (data[offset + 1].toInt() and 0xff)

    private fun put16(data: ByteArray, offset: Int, value: Int) {
        data[offset] = (value ushr 8).toByte()
        data[offset + 1] = value.toByte()
    }

    private fun checksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        val end = offset + length
        while (i + 1 < end) {
            sum += (((data[i].toInt() and 0xff) shl 8) or (data[i + 1].toInt() and 0xff)).toLong()
            i += 2
        }
        if (i < end) sum += ((data[i].toInt() and 0xff) shl 8).toLong()
        while ((sum ushr 16) != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }
}
