package ru.aidnsswitcher.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val executor = Executors.newFixedThreadPool(7)
    private val preferences by lazy { getSharedPreferences("ai_dns_switcher", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var profileContainer: LinearLayout
    private lateinit var appContainer: LinearLayout
    private lateinit var results: LinearLayout
    private lateinit var toggleButton: Button
    private lateinit var testButton: Button
    private var selectedProfileId = "geohide-eu"
    private var selectedPackages: MutableSet<String> = linkedSetOf()
    private var showAllApps = false
    private var pendingStart = false
    private var lastRenderedRunning: Boolean? = null
    private var diagnosticRunning = false
    private val statusHandler = Handler(Looper.getMainLooper())
    private val statusRefresh = object : Runnable {
        override fun run() {
            refreshVpnStatus()
            statusHandler.postDelayed(this, 1_000)
        }
    }
    private val allLaunchableApps by lazy { loadLaunchableApps() }

    private val services = listOf(
        "ChatGPT" to "chatgpt.com",
        "Gemini" to "gemini.google.com",
        "Claude" to "claude.ai",
        "DeepSeek" to "chat.deepseek.com",
        "Perplexity" to "www.perplexity.ai",
        "ElevenLabs" to "elevenlabs.io"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
        }
        selectedProfileId = preferences.getString("profile_id", "geohide-eu") ?: "geohide-eu"
        selectedPackages = preferences.getStringSet("selected_packages", emptySet())?.toMutableSet() ?: linkedSetOf()
        buildUi()
        renderProfiles()
        renderApps()
        refreshVpnStatus()
        showMessage("Выбери приложения, DNS-профиль и включи перехват.")
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(30))
            setBackgroundColor(0xFFF4F6FA.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)
        if (android.os.Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(dp(18), dp(22) + bars.top, dp(18), dp(30) + bars.bottom)
                insets
            }
        }

        root.addView(text("AI DNS Switcher", 27, true, 0xFF172033.toInt()))
        root.addView(text("Выборочный Smart DNS для AI-приложений", 14, false, 0xFF667085.toInt()).apply {
            setPadding(0, dp(5), 0, dp(14))
        })

        status = text("", 14, false, 0xFF344054.toInt()).apply {
            setPadding(dp(14), dp(13), dp(14), dp(13))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(status, matchWrap())

        root.addView(sectionTitle("1. DNS-профиль"))
        profileContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(profileContainer)

        root.addView(sectionTitle("2. Приложения"))
        root.addView(text("Весь трафик отмеченных приложений проходит через локальный туннель; DNS-запросы отправляются выбранному Smart DNS. Остальные приложения не затрагиваются.", 12, false, 0xFF667085.toInt()))
        val showAll = CheckBox(this).apply {
            text = "Показать все приложения с ярлыком запуска"
            isChecked = showAllApps
            setOnCheckedChangeListener { _, checked ->
                showAllApps = checked
                renderApps()
            }
        }
        root.addView(showAll)
        appContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(appContainer)

        root.addView(sectionTitle("3. Управление"))
        toggleButton = Button(this).apply {
            text = "Включить для выбранных приложений"
            isAllCaps = false
            setOnClickListener {
                if (AiDnsVpnService.isRunning) stopVpn() else requestVpnAndStart()
            }
        }
        root.addView(toggleButton, matchWrap())

        testButton = Button(this).apply {
            text = "Проверить все профили и выбрать лучший"
            isAllCaps = false
            setOnClickListener { autoSelectBestProfile() }
        }
        root.addView(testButton, matchWrap())

        root.addView(sectionTitle("Результаты диагностики"))
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(results)

        root.addView(text(
            "Весь IPv4/IPv6-трафик отмеченных приложений проходит через локальный TUN → SOCKS5-модуль на телефоне → обычную сеть. Удалённого VPN-сервера нет. DNS по UDP/TCP порту 53 отправляется через DoH выбранного Smart DNS; прочий трафик соединяется напрямую через сеть телефона. При отказе всех DNS-профилей трафик отмеченных приложений блокируется. Защита действует, пока Android сохраняет VPN-службу; принудительная остановка, отзыв разрешения или запуск другого VPN могут снять её. Встроенный DoH/DoT самого приложения или заданный вручную «Частный DNS» Android может использовать другой резолвер.",
            12, false, 0xFF8A3B12.toInt()
        ).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFFFF4E5.toInt())
        })
    }

    private fun renderProfiles() {
        profileContainer.removeAllViews()
        DnsProfiles.builtIn.forEach { profile ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(13), dp(11), dp(13), dp(11))
                setBackgroundColor(if (profile.id == selectedProfileId) 0xFFEAF0FF.toInt() else 0xFFFFFFFF.toInt())
            }
            card.addView(text(profile.name, 16, true, 0xFF172033.toInt()))
            card.addView(text(profile.note, 12, false, 0xFF667085.toInt()).apply { setPadding(0, dp(3), 0, dp(2)) })
            card.addView(text(profile.dohUrl, 11, false, 0xFF475467.toInt()))
            val choose = Button(this).apply {
                text = if (profile.id == selectedProfileId) "Выбран" else "Выбрать"
                isAllCaps = false
                setOnClickListener {
                    selectedProfileId = profile.id
                    preferences.edit().putString("profile_id", selectedProfileId).apply()
                    renderProfiles()
                    updateRunningProfile()
                    showMessage("Выбран профиль ${profile.name}.")
                }
            }
            card.addView(choose)
            profileContainer.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun renderApps() {
        appContainer.removeAllViews()
        val apps = if (showAllApps) allLaunchableApps else {
            val known = knownAiPackages.mapNotNull { pkg -> allLaunchableApps.firstOrNull { it.packageName == pkg } }
            if (known.isNotEmpty()) known else allLaunchableApps.filter { app ->
                val lower = app.label.lowercase()
                listOf("chatgpt", "gemini", "claude", "deepseek", "perplexity", "copilot", "ai").any { it in lower }
            }
        }

        if (apps.isEmpty()) {
            appContainer.addView(text("Не удалось найти подходящие приложения. Включи показ всех приложений.", 13, false, 0xFFB42318.toInt()))
            return
        }

        if (AiDnsVpnService.isRunning) {
            appContainer.addView(text(
                "Чтобы изменить список приложений, сначала выключи защищённый режим.",
                12, false, 0xFF8A3B12.toInt()
            ))
        }
        apps.forEach { app ->
            val check = CheckBox(this).apply {
                text = "${app.label}  (${app.packageName})"
                textSize = 13f
                isChecked = selectedPackages.contains(app.packageName)
                isEnabled = !AiDnsVpnService.isRunning && !diagnosticRunning
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selectedPackages.add(app.packageName) else selectedPackages.remove(app.packageName)
                    preferences.edit().putStringSet("selected_packages", selectedPackages.toSet()).apply()
                }
            }
            appContainer.addView(check)
        }
    }

    private fun loadLaunchableApps(): List<AiApp> {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = packageManager.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
        val map = linkedMapOf<String, AiApp>()
        resolved.forEach { info ->
            val appInfo = info.activityInfo?.applicationInfo ?: return@forEach
            if (appInfo.packageName == packageName) return@forEach
            val label = info.loadLabel(packageManager)?.toString()?.takeIf { it.isNotBlank() } ?: appInfo.packageName
            map[appInfo.packageName] = AiApp(appInfo.packageName, label)
        }
        val priority = knownAiPackages.withIndex().associate { it.value to it.index }
        return map.values.sortedWith(compareBy<AiApp>({ priority[it.packageName] ?: Int.MAX_VALUE }, { it.label.lowercase() }))
    }

    private val knownAiPackages = listOf(
        "com.openai.chatgpt",
        "com.google.android.apps.bard",
        "com.anthropic.claude",
        "com.deepseek.chat",
        "ai.perplexity.app.android",
        "com.microsoft.office.officehubrow",
        "com.microsoft.copilot"
    )

    private fun requestVpnAndStart() {
        if (selectedPackages.isEmpty()) {
            showMessage("Сначала отметь хотя бы одно приложение.")
            return
        }
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            pendingStart = true
            toggleButton.isEnabled = false
            startActivityForResult(prepareIntent, REQUEST_VPN)
        } else {
            startVpnService()
        }
    }

    private fun startVpnService() {
        val profile = DnsProfiles.builtIn.first { it.id == selectedProfileId }
        val intent = Intent(this, AiDnsVpnService::class.java).apply {
            action = AiDnsVpnService.ACTION_START
            putExtra(AiDnsVpnService.EXTRA_DOH_URL, profile.dohUrl)
            putStringArrayListExtra(AiDnsVpnService.EXTRA_PACKAGES, ArrayList(selectedPackages))
        }
        startForegroundService(intent)
        showMessage("Запуск локального защищённого туннеля… Подтверди системный запрос Android, если он появится.")
        status.postDelayed({ refreshVpnStatus() }, 600)
        status.postDelayed({ refreshVpnStatus() }, 1600)
    }

    private fun stopVpn() {
        status.text = "Отключение защищённого режима…"
        toggleButton.isEnabled = false
        startService(Intent(this, AiDnsVpnService::class.java).setAction(AiDnsVpnService.ACTION_STOP))
        status.postDelayed({ refreshVpnStatus() }, 500)
    }

    private fun updateRunningProfile() {
        if (!AiDnsVpnService.isRunning) return
        val profile = DnsProfiles.builtIn.first { it.id == selectedProfileId }
        startService(Intent(this, AiDnsVpnService::class.java).apply {
            action = AiDnsVpnService.ACTION_UPDATE_PROFILE
            putExtra(AiDnsVpnService.EXTRA_DOH_URL, profile.dohUrl)
        })
        showMessage("Активный DNS-профиль изменён на ${profile.name}.")
    }

    private fun probeTargetsForSelection(): Pair<List<Pair<String, String>>, Set<String>> {
        val targetsByPackage = mapOf(
            "com.openai.chatgpt" to ("ChatGPT" to "chatgpt.com"),
            "com.google.android.apps.bard" to ("Gemini" to "gemini.google.com"),
            "com.anthropic.claude" to ("Claude" to "claude.ai"),
            "com.deepseek.chat" to ("DeepSeek" to "chat.deepseek.com"),
            "ai.perplexity.app.android" to ("Perplexity" to "www.perplexity.ai"),
            "com.microsoft.copilot" to ("Copilot" to "copilot.microsoft.com"),
            "com.microsoft.office.officehubrow" to ("Copilot" to "copilot.microsoft.com")
        )
        val selected = selectedPackages.toList()
        val knownTargets = selected.mapNotNull(targetsByPackage::get).distinctBy { it.second }
        val targets = when {
            knownTargets.isEmpty() -> services
            selected.any { it !in targetsByPackage } -> services
            else -> knownTargets
        }
        return targets to knownTargets.map { it.second }.toSet()
    }

    private fun autoSelectBestProfile() {
        if (diagnosticRunning) return
        diagnosticRunning = true
        testButton.isEnabled = false
        testButton.text = "Проверяю профили…"
        renderApps()
        results.removeAllViews()
        val (targets, requiredHosts) = probeTargetsForSelection()
        val targetLabel = targets.joinToString { it.first }
        showMessage("Проверяю ${DnsProfiles.builtIn.size} профилей для: $targetLabel. Оценка основана на DNS и HTTPS-ответах.")

        executor.execute {
            val rendered = try {
                // Run the provider/service matrix concurrently with a bounded pool.
                // The activity task occupies one worker; six probe workers run in parallel.
                val pending = DnsProfiles.builtIn.associateWith { profile ->
                    targets.map { service ->
                        executor.submit<ProbeResult> { DnsProbe.checkProfile(profile, service) }
                    }
                }
                DnsProfiles.builtIn.map { profile ->
                    val checks = pending.getValue(profile).map { future ->
                        try {
                            future.get(18, TimeUnit.SECONDS)
                        } catch (e: Exception) {
                            future.cancel(true)
                            ProbeResult("Проверка", "Тайм-аут или ошибка проверки", false)
                        }
                    }
                    profile to checks
                }
            } catch (e: Throwable) {
                emptyList()
            }

            val eligible = rendered.filter { (_, checks) ->
                if (requiredHosts.isNotEmpty()) {
                    targets.indices.filter { targets[it].second in requiredHosts }
                        .all { index -> checks.getOrNull(index)?.ok == true }
                } else {
                    checks.any { it.ok }
                }
            }
            val best = eligible.maxByOrNull { (_, checks) -> checks.count { it.ok } }

            runOnUiThread {
                rendered.forEach { (profile, checks) ->
                    val count = checks.count { it.ok }
                    val card = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(dp(12), dp(10), dp(12), dp(10))
                        setBackgroundColor(0xFFFFFFFF.toInt())
                    }
                    card.addView(text("${profile.name}: $count/${targets.size}", 15, true, 0xFF172033.toInt()))
                    checks.forEach { check ->
                        card.addView(text("${check.service}: ${check.detail}", 11, false,
                            if (check.ok) 0xFF067647.toInt() else 0xFFB42318.toInt()).apply {
                            setPadding(0, dp(3), 0, 0)
                        })
                    }
                    results.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
                }
                if (best != null) {
                    selectedProfileId = best.first.id
                    preferences.edit().putString("profile_id", selectedProfileId).apply()
                    renderProfiles()
                    updateRunningProfile()
                    showMessage("Выбран ${best.first.name}: ${best.second}/${targets.size} проверок успешны. Это сетевой тест, не гарантия авторизации или работы всех функций.")
                } else if (rendered.isEmpty()) {
                    showMessage("Не удалось выполнить диагностику. Проверь подключение к интернету и повтори попытку.")
                } else if (requiredHosts.isNotEmpty()) {
                    showMessage("Ни один профиль не прошёл проверки для всех выбранных AI-приложений. Профиль не изменён.")
                } else {
                    showMessage("Ни один профиль не обеспечил успешную проверку AI-сервисов. Профиль не изменён.")
                }
                diagnosticRunning = false
                testButton.isEnabled = true
                testButton.text = "Проверить все профили и выбрать лучший"
                renderApps()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VPN && pendingStart) {
            pendingStart = false
            if (resultCode == RESULT_OK) startVpnService() else showMessage("Разрешение Android на локальный сетевой интерфейс не предоставлено.")
        }
    }

    override fun onResume() {
        super.onResume()
        statusHandler.removeCallbacks(statusRefresh)
        statusHandler.post(statusRefresh)
        val latestProfile = preferences.getString("profile_id", selectedProfileId) ?: selectedProfileId
        if (latestProfile != selectedProfileId) {
            selectedProfileId = latestProfile
            if (::profileContainer.isInitialized) renderProfiles()
        }
        refreshVpnStatus()
    }

    override fun onPause() {
        statusHandler.removeCallbacks(statusRefresh)
        super.onPause()
    }

    private fun refreshVpnStatus() {
        if (!::status.isInitialized) return
        val latestProfile = preferences.getString("profile_id", selectedProfileId) ?: selectedProfileId
        if (latestProfile != selectedProfileId) {
            selectedProfileId = latestProfile
            if (::profileContainer.isInitialized) renderProfiles()
        }
        val runningNow = AiDnsVpnService.isRunning
        status.text = if (runningNow) {
            AiDnsVpnService.statusText
        } else {
            "Защищённый режим выключен"
        }
        toggleButton.text = if (runningNow) "Выключить защищённый режим" else "Включить для выбранных приложений"
        toggleButton.isEnabled = true
        if (::appContainer.isInitialized && lastRenderedRunning != runningNow) {
            lastRenderedRunning = runningNow
            renderApps()
        }
    }

    private fun showMessage(message: String) {
        status.text = if (AiDnsVpnService.isRunning) AiDnsVpnService.statusText else message
        toggleButton.isEnabled = true
    }

    private fun sectionTitle(value: String) = text(value, 18, true, 0xFF172033.toInt()).apply {
        setPadding(0, dp(17), 0, dp(8))
    }

    private fun text(value: String, size: Int, bold: Boolean, color: Int) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        statusHandler.removeCallbacks(statusRefresh)
        executor.shutdownNow()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_VPN = 9001
        private const val REQUEST_NOTIFICATIONS = 9002
    }
}
