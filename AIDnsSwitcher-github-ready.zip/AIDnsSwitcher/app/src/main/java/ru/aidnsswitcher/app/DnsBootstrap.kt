package ru.aidnsswitcher.app

import okhttp3.Dns
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Uses Android's ordinary resolver for the DoH provider hostname. The app process
 * itself is excluded from the per-app VPN allow-list, so these control-plane sockets
 * use the underlying network and do not recurse into the local TUN.
 *
 * Provider IPs are deliberately not hardcoded: stale bootstrap IPs can silently send
 * TLS to the wrong host or make a healthy provider look unavailable.
 */
object DnsBootstrap {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(Dns.SYSTEM)
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .writeTimeout(5, TimeUnit.SECONDS)
            .callTimeout(7, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }
}
