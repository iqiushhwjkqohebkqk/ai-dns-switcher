package ru.aidnsswitcher.app

import java.net.InetAddress
import java.net.Inet6Address

/** RFC 1928 UDP request/response framing used between tun2socks and the local relay. */
object Socks5UdpCodec {
    data class DatagramRequest(
        val addressType: Int,
        val addressBytes: ByteArray,
        val host: String,
        val port: Int,
        val payload: ByteArray
    )

    fun parse(data: ByteArray, length: Int): DatagramRequest? {
        if (length < 10 || data[0].toInt() != 0 || data[1].toInt() != 0 || data[2].toInt() != 0) return null
        var offset = 4
        val atyp = data[3].toInt() and 0xff
        val addressBytes: ByteArray
        val host: String
        when (atyp) {
            1 -> {
                if (length < offset + 4 + 2 + 1) return null
                addressBytes = data.copyOfRange(offset, offset + 4)
                host = addressBytes.joinToString(".") { (it.toInt() and 0xff).toString() }
                offset += 4
            }
            3 -> {
                val size = data[offset].toInt() and 0xff
                offset++
                if (size == 0 || length < offset + size + 2 + 1) return null
                addressBytes = data.copyOfRange(offset, offset + size)
                host = data.copyOfRange(offset, offset + size).toString(Charsets.US_ASCII)
                offset += size
            }
            4 -> {
                if (length < offset + 16 + 2 + 1) return null
                addressBytes = data.copyOfRange(offset, offset + 16)
                host = InetAddress.getByAddress(addressBytes).hostAddress ?: return null
                offset += 16
            }
            else -> return null
        }
        val port = ((data[offset].toInt() and 0xff) shl 8) or (data[offset + 1].toInt() and 0xff)
        offset += 2
        if (port == 0 || offset >= length) return null
        return DatagramRequest(atyp, addressBytes, host, port, data.copyOfRange(offset, length))
    }

    /** Build a response using the original request destination as the DNS response source. */
    fun responseForRequest(request: DatagramRequest, payload: ByteArray): ByteArray =
        frame(request.addressType, request.addressBytes, request.port, payload)

    fun responseFrom(address: InetAddress, port: Int, payload: ByteArray): ByteArray {
        val bytes = address.address
        return frame(if (address is Inet6Address) 4 else 1, bytes, port, payload)
    }

    private fun frame(atyp: Int, address: ByteArray, port: Int, payload: ByteArray): ByteArray {
        val addressPrefix = if (atyp == 3) byteArrayOf(address.size.toByte()) else ByteArray(0)
        val out = ByteArray(3 + 1 + addressPrefix.size + address.size + 2 + payload.size)
        out[3] = atyp.toByte()
        var offset = 4
        addressPrefix.copyInto(out, offset); offset += addressPrefix.size
        address.copyInto(out, offset); offset += address.size
        out[offset++] = (port ushr 8).toByte()
        out[offset++] = port.toByte()
        payload.copyInto(out, offset)
        return out
    }
}
