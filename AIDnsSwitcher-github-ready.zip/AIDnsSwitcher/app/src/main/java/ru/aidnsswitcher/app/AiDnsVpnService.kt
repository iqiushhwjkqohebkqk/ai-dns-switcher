package ru.aidnsswitcher.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Per-app full-tunnel implementation. Only selected packages enter Android's TUN.
 * The TUN is handled by the open-source Hev tun2socks engine and a SOCKS5 relay bound
 * to 127.0.0.1. The relay opens normal sockets over the phone's underlying network;
 * no remote VPN server or commercial VPN account is involved.
 *
 * UDP/TCP DNS port 53 is intercepted by the local SOCKS relay and sent over the
 * selected Smart-DNS DoH endpoint. Other TCP/UDP is forwarded directly.
 */
class AiDnsVpnService : VpnService() {
    enum class TunnelMode { STOPPED, ACTIVE, BLOCKED }

    private data class TunnelContext(val descriptor: ParcelFileDescriptor)

    companion object {
        const val ACTION_START = "ru.aidnsswitcher.app.START"
        const val ACTION_STOP = "ru.aidnsswitcher.app.STOP"
        const val ACTION_UPDATE_PROFILE = "ru.aidnsswitcher.app.UPDATE_PROFILE"
        const val EXTRA_DOH_URL = "doh_url"
        const val EXTRA_PACKAGES = "packages"

        private const val CHANNEL_ID = "ai_dns_active"
        private const val NOTIFICATION_ID = 4107
        private const val TAG = "AiDnsVpnService"
        private const val LOCAL_DNS = "198.18.0.2"
        private const val TUN_IPV4 = "198.18.0.1"
        private const val TUN_IPV6 = "fc00::1"
        private const val SOCKS_HOST = "127.0.0.1"

        @Volatile var isRunning: Boolean = false
            private set
        @Volatile var currentMode: TunnelMode = TunnelMode.STOPPED
            private set
        @Volatile var statusText: String = "Защищённый режим выключен"
            private set
    }

    @Volatile private var dohUrl: String = DnsProfiles.builtIn.first().dohUrl
    @Volatile private var selectedPackages: List<String> = emptyList()
    @Volatile private var activeTunnel: TunnelContext? = null
    @Volatile private var socksServer: LocalSocks5Server? = null
    @Volatile private var socksUsername: String = ""
    @Volatile private var socksPassword: String = ""
    @Volatile private var socksPort: Int = 0

    private val healthTargetByPackage = mapOf(
        "com.openai.chatgpt" to ("ChatGPT" to "chatgpt.com"),
        "com.google.android.apps.bard" to ("Gemini" to "gemini.google.com"),
        "com.anthropic.claude" to ("Claude" to "claude.ai"),
        "com.deepseek.chat" to ("DeepSeek" to "chat.deepseek.com"),
        "ai.perplexity.app.android" to ("Perplexity" to "www.perplexity.ai"),
        "com.microsoft.copilot" to ("Copilot" to "copilot.microsoft.com"),
        "com.microsoft.office.officehubrow" to ("Copilot" to "copilot.microsoft.com")
    )

    private val running = AtomicBoolean(false)
    private val switching = AtomicBoolean(false)
    private val lifecycleLock = Any()
    @Volatile private var healthExecutor = Executors.newSingleThreadScheduledExecutor()
    @Volatile private var probeExecutor = Executors.newFixedThreadPool(6)
    private val controlExecutor = Executors.newSingleThreadExecutor()
    private val dohClient by lazy { DnsBootstrap.client }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val preferences = getSharedPreferences("ai_dns_switcher", MODE_PRIVATE)
        if (intent == null) {
            if (!preferences.getBoolean("service_enabled", false)) return START_NOT_STICKY
            dohUrl = preferences.getString("active_doh_url", DnsProfiles.builtIn.first().dohUrl)
                ?.takeIf(::isAllowedDohUrl) ?: DnsProfiles.builtIn.first().dohUrl
            selectedPackages = preferences.getStringSet("active_packages", emptySet())
                ?.filterNot { it == packageName }.orEmpty()
            startForegroundCompat("Восстановление защищённого режима")
            controlExecutor.execute { startTunnel() }
            return START_STICKY
        }

        when (intent.action) {
            ACTION_STOP -> {
                preferences.edit().putBoolean("service_enabled", false).apply()
                controlExecutor.execute {
                    stopTunnel()
                    stopSelf()
                }
                return START_NOT_STICKY
            }
            ACTION_UPDATE_PROFILE -> {
                intent.getStringExtra(EXTRA_DOH_URL)?.takeIf(::isAllowedDohUrl)?.let { url ->
                    dohUrl = url
                    preferences.edit().putString("active_doh_url", url).apply()
                    rememberSelectedProfile(url)
                    updateStatus("DNS-профиль изменён: ${profileName(url)}")
                }
                return START_STICKY
            }
            ACTION_START -> {
                dohUrl = intent.getStringExtra(EXTRA_DOH_URL)
                    ?.takeIf(::isAllowedDohUrl) ?: DnsProfiles.builtIn.first().dohUrl
                selectedPackages = intent.getStringArrayListExtra(EXTRA_PACKAGES)
                    .orEmpty().distinct().filterNot { it == packageName }
                preferences.edit()
                    .putBoolean("service_enabled", true)
                    .putString("active_doh_url", dohUrl)
                    .putStringSet("active_packages", selectedPackages.toSet())
                    .apply()
                startForegroundCompat("Подключение защищённого режима")
                controlExecutor.execute { startTunnel() }
            }
        }
        return START_STICKY
    }

    private fun startTunnel() {
        stopTunnel(removeNotification = false)
        healthExecutor = Executors.newSingleThreadScheduledExecutor()
        probeExecutor = Executors.newFixedThreadPool(6)
        if (selectedPackages.isEmpty()) {
            getSharedPreferences("ai_dns_switcher", MODE_PRIVATE).edit()
                .putBoolean("service_enabled", false).apply()
            updateStatus("Не выбраны приложения")
            stopSelf()
            return
        }
        try {
            startSocksRelay()
            val context = createFullTunnel()
            activeTunnel = context
            running.set(true)
            isRunning = true
            currentMode = TunnelMode.ACTIVE
            val nativeStarted = startNativeTunnel(context)
            if (!running.get() || activeTunnel !== context) {
                runCatching { HevTunnelBridge.stop() }
                return
            }
            if (!nativeStarted) {
                activateFailClosed("Не удалось запустить локальный туннель")
                startHealthMonitor()
                return
            }
            updateStatus("Полный локальный туннель включён · ${selectedPackages.size} прилож.")
            startHealthMonitor()
        } catch (e: Exception) {
            Log.e(TAG, "Unable to start protected tunnel", e)
            stopTunnel()
            updateStatus("Не удалось запустить туннель: ${e.message ?: "ошибка"}")
            stopSelf()
        }
    }

    private fun createFullTunnel(): TunnelContext {
        val builder = Builder()
            .setSession("AI DNS Switcher")
            .setMtu(1500)
            .setBlocking(false)
            .addAddress(TUN_IPV4, 32)
            .addAddress(TUN_IPV6, 128)
            .addDnsServer(LOCAL_DNS)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)

        var added = 0
        selectedPackages.forEach { app ->
            try {
                builder.addAllowedApplication(app)
                added++
            } catch (e: Exception) {
                Log.w(TAG, "Skipping unavailable app $app", e)
            }
        }
        check(added > 0) { "Ни одно выбранное приложение не установлено" }
        val descriptor = builder.establish() ?: error("Android не создал VPN-интерфейс")
        return TunnelContext(descriptor)
    }

    private fun startSocksRelay(regenerateCredentials: Boolean = true) {
        socksServer?.close()
        if (regenerateCredentials || socksUsername.isBlank() || socksPassword.isBlank()) {
            socksUsername = java.util.UUID.randomUUID().toString().replace("-", "")
            socksPassword = java.util.UUID.randomUUID().toString().replace("-", "")
        }
        val relay = LocalSocks5Server(
            protectSocket = { socket -> protect(socket) },
            protectDatagram = { socket -> protect(socket) },
            resolveDns = { query -> queryDoH(query) },
            onFatalError = { error ->
                Log.e(TAG, "Local SOCKS5 relay failed", error)
                controlExecutor.execute { activateFailClosed("Ошибка локального сетевого шлюза") }
            },
            username = socksUsername,
            password = socksPassword,
            port = socksPort
        )
        relay.start()
        socksPort = relay.boundPort
        socksServer = relay
    }

    private fun nativeConfigFile(): File {
        val file = File(cacheDir, "hev-socks5-tunnel.yml")
        val config = """misc:
  task-stack-size: 81920
  log-level: warn
tunnel:
  mtu: 1500
  ipv4: $TUN_IPV4
  ipv6: '$TUN_IPV6'
  icmp: 'reply'
socks5:
  address: '$SOCKS_HOST'
  port: $socksPort
  udp: 'udp'
  udp-address: '$SOCKS_HOST'
  username: '$socksUsername'
  password: '$socksPassword'
""".trimIndent()
        file.writeText(config)
        return file
    }

    private fun startNativeTunnel(context: TunnelContext): Boolean {
        val config = nativeConfigFile()
        return try {
            // The native start call reports whether the engine accepted the TUN.
            // Its running state is monitored asynchronously to avoid a startup race.
            HevTunnelBridge.start(config.absolutePath, context.descriptor.fd)
        } catch (e: Throwable) {
            Log.e(TAG, "Hev native tunnel failed to load/start", e)
            false
        }
    }

    /**
     * Fail closed by keeping the full per-app TUN installed and closing the local
     * SOCKS5 relay. The native tun2socks engine, when alive, continues to drain the
     * TUN but has no upstream proxy to connect to. If the native engine has died,
     * the TUN file descriptor remains established and packets have no direct route.
     */
    private fun activateFailClosed(reason: String) = synchronized(lifecycleLock) {
        if ((!running.get() && activeTunnel == null) || currentMode == TunnelMode.BLOCKED) return@synchronized
        if (!switching.compareAndSet(false, true)) return@synchronized
        try {
            runCatching { socksServer?.close() }
            socksServer = null
            running.set(true)
            isRunning = true
            currentMode = TunnelMode.BLOCKED
            updateStatus("$reason · весь трафик выбранных приложений заблокирован")
        } finally {
            switching.set(false)
        }
    }

    private fun restoreTunnel(profile: DnsProfile) = synchronized(lifecycleLock) {
        if (!running.get() || currentMode != TunnelMode.BLOCKED) return@synchronized
        if (!switching.compareAndSet(false, true)) return@synchronized
        try {
            dohUrl = profile.dohUrl
            rememberSelectedProfile(dohUrl)

            if (HevTunnelBridge.isRunning()) {
                // The TUN engine is still draining packets. Reopen only the local
                // authenticated relay with the same credentials stored in its config.
                startSocksRelay(regenerateCredentials = false)
                currentMode = TunnelMode.ACTIVE
                updateStatus("DNS восстановлен: ${profile.name} · блокировка снята")
                return@synchronized
            }

            // The native engine stopped. Replace the established TUN first, so the
            // selected apps never get a window in which they fall back to direct net.
            runCatching { HevTunnelBridge.stop() }
            startSocksRelay(regenerateCredentials = true)
            val previous = activeTunnel
            val next = createFullTunnel()
            activeTunnel = next
            // establish() replaces this service's previous VPN interface.
            runCatching { previous?.descriptor?.close() }
            if (!startNativeTunnel(next)) {
                runCatching { HevTunnelBridge.stop() }
                socksServer?.close(); socksServer = null
                currentMode = TunnelMode.BLOCKED
                updateStatus("Профиль доступен, но локальный туннель не запустился · приложения остаются заблокированы")
                return
            }
            currentMode = TunnelMode.ACTIVE
            updateStatus("DNS восстановлен: ${profile.name} · блокировка снята")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to restore tunnel", e)
            runCatching { socksServer?.close() }
            socksServer = null
            currentMode = TunnelMode.BLOCKED
            updateStatus("Ошибка восстановления · выбранные приложения остаются заблокированы")
        } finally {
            switching.set(false)
        }
    }

    private data class HealthPlan(
        val targets: List<Pair<String, String>>,
        val requiredHosts: Set<String>
    )

    /** Known selected AI apps must pass their own site checks. If a browser or
     * unknown app is also selected, run the broader matrix but still require all
     * checks corresponding to known AI apps. Unknown-only selections require at
     * least one reachable AI service because the future destination is unknown. */
    private fun healthPlan(): HealthPlan {
        val mapped = selectedPackages.mapNotNull(healthTargetByPackage::get).distinctBy { it.second }
        val hasUnknownPackage = selectedPackages.any { it !in healthTargetByPackage }
        val targets = when {
            mapped.isEmpty() -> listOf(
                "ChatGPT" to "chatgpt.com",
                "Gemini" to "gemini.google.com",
                "Claude" to "claude.ai",
                "DeepSeek" to "chat.deepseek.com",
                "Perplexity" to "www.perplexity.ai",
                "ElevenLabs" to "elevenlabs.io"
            )
            hasUnknownPackage -> listOf(
                "ChatGPT" to "chatgpt.com",
                "Gemini" to "gemini.google.com",
                "Claude" to "claude.ai",
                "DeepSeek" to "chat.deepseek.com",
                "Perplexity" to "www.perplexity.ai",
                "ElevenLabs" to "elevenlabs.io"
            )
            else -> mapped
        }
        return HealthPlan(targets, mapped.map { it.second }.toSet())
    }

    private fun startHealthMonitor() {
        // Capture the executors for this tunnel generation. If the user rapidly
        // stops/restarts the service, an old probe cycle must not alter the new one.
        val scheduler = healthExecutor
        val probePool = probeExecutor
        scheduler.scheduleWithFixedDelay({
            if (!running.get() || healthExecutor !== scheduler) return@scheduleWithFixedDelay
            try {
                if (currentMode == TunnelMode.ACTIVE && !HevTunnelBridge.isRunning()) {
                    activateFailClosed("Локальный туннель неожиданно остановился")
                    return@scheduleWithFixedDelay
                }
                val plan = healthPlan()
                val pending = DnsProfiles.builtIn.associateWith { profile ->
                    plan.targets.map { target ->
                        probePool.submit<ProbeResult> { DnsProbe.checkProfile(profile, target) }
                    }
                }
                val checked = DnsProfiles.builtIn.map { profile ->
                    val futures = pending.getValue(profile)
                    val results = futures.map { future ->
                        try {
                            future.get(20, TimeUnit.SECONDS)
                        } catch (e: Exception) {
                            future.cancel(true)
                            ProbeResult("Проверка", "Тайм-аут или ошибка", false)
                        }
                    }
                    Triple(profile, results, results.count { it.ok })
                }
                if (!running.get() || healthExecutor !== scheduler) return@scheduleWithFixedDelay
                val eligible = checked.filter { (_, results, _) ->
                    if (plan.requiredHosts.isNotEmpty()) {
                        plan.targets.indices.filter { plan.targets[it].second in plan.requiredHosts }
                            .all { index -> results.getOrNull(index)?.ok == true }
                    } else {
                        results.any { it.ok }
                    }
                }
                val best = eligible.maxByOrNull { it.third }
                if (best == null) {
                    val maximum = checked.maxOfOrNull { it.third } ?: 0
                    if (currentMode == TunnelMode.ACTIVE) {
                        activateFailClosed("Ни один профиль не прошёл целевые проверки (${maximum}/${plan.targets.size})")
                    }
                    return@scheduleWithFixedDelay
                }
                if (currentMode == TunnelMode.BLOCKED) {
                    restoreTunnel(best.first)
                } else {
                    val current = checked.firstOrNull { it.first.dohUrl == dohUrl }?.third ?: -1
                    if (best.third > current && best.first.dohUrl != dohUrl) {
                        dohUrl = best.first.dohUrl
                        rememberSelectedProfile(dohUrl)
                        updateStatus("Автопереключение DNS: ${best.first.name} · ${best.third}/${plan.targets.size}")
                    }
                }
            } catch (e: Throwable) {
                Log.w(TAG, "Health check failed", e)
            }
        }, 2, 10, TimeUnit.MINUTES)
    }

    private fun queryDoH(dnsMessage: ByteArray): ByteArray {
        require(dnsMessage.size in 12..8192) { "Некорректный DNS-запрос" }
        val preferred = dohUrl
        val candidates = listOf(preferred) + DnsProfiles.builtIn.map { it.dohUrl }.filter { it != preferred }
        var lastError: Throwable? = null
        var lastNxDomain: ByteArray? = null
        for (candidate in candidates) {
            try {
                val response = requestDoH(candidate, dnsMessage)
                if (DnsPacketCodec.responseCode(response) == 3) {
                    // NXDOMAIN can be a provider-specific block response. Try the
                    // remaining profiles; if every provider agrees, return NXDOMAIN.
                    lastNxDomain = response
                    continue
                }
                if (candidate != preferred) {
                    dohUrl = candidate
                    rememberSelectedProfile(candidate)
                    updateStatus("Автопереключение DNS: ${profileName(candidate)}")
                }
                return response
            } catch (e: Throwable) {
                lastError = e
                Log.w(TAG, "DoH failed: $candidate", e)
            }
        }
        if (lastNxDomain != null) return lastNxDomain
        activateFailClosed("Все DNS-профили недоступны")
        throw lastError ?: IllegalStateException("Нет доступных DoH-профилей")
    }

    private fun requestDoH(endpoint: String, dnsMessage: ByteArray): ByteArray {
        val mediaType = "application/dns-message".toMediaType()
        val request = Request.Builder()
            .url(endpoint)
            .post(dnsMessage.toRequestBody(mediaType))
            .header("Accept", "application/dns-message")
            .header("User-Agent", "AI-DNS-Switcher/0.4.9")
            .build()
        dohClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("DoH HTTP ${response.code}")
            val body = response.body?.bytes() ?: error("Пустой DoH-ответ")
            require(DnsPacketCodec.isAcceptableDnsResponse(dnsMessage, body)) {
                "Некорректный DNS-ответ или ошибка резолвера"
            }
            return body
        }
    }

    private fun isAllowedDohUrl(value: String): Boolean =
        DnsProfiles.builtIn.any { it.dohUrl == value } ||
            (value.startsWith("https://") && value.endsWith("/dns-query") && value.length < 300)

    private fun profileName(url: String): String =
        DnsProfiles.builtIn.firstOrNull { it.dohUrl == url }?.name ?: "Пользовательский профиль"

    private fun rememberSelectedProfile(url: String) {
        val preferences = getSharedPreferences("ai_dns_switcher", MODE_PRIVATE)
        preferences.edit().putString("active_doh_url", url).apply()
        DnsProfiles.builtIn.firstOrNull { it.dohUrl == url }?.let { profile ->
            preferences.edit().putString("profile_id", profile.id).apply()
        }
    }

    private fun startForegroundCompat(message: String) {
        val notification = buildNotification(message)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(text: String): Notification {
        createNotificationChannel()
        val openIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pendingIntent = openIntent?.let {
            PendingIntent.getActivity(this, 0, it,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
        else Notification.Builder(this)
        return builder.setContentTitle("AI DNS Switcher")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun updateStatus(message: String) {
        statusText = message
        Log.i(TAG, message)
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(message))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "AI DNS Switcher", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun stopTunnel(removeNotification: Boolean = true) = synchronized(lifecycleLock) {
        running.set(false)
        isRunning = false
        currentMode = TunnelMode.STOPPED
        statusText = "Защищённый режим выключен"
        runCatching { healthExecutor.shutdownNow() }
        runCatching { probeExecutor.shutdownNow() }
        runCatching { HevTunnelBridge.stop() }
        runCatching { socksServer?.close() }
        socksServer = null
        socksPort = 0
        val previous = activeTunnel
        activeTunnel = null
        runCatching { previous?.descriptor?.close() }
        if (removeNotification) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.cancel(NOTIFICATION_ID)
            stopForeground(STOP_FOREGROUND_REMOVE)
        }
    }

    override fun onRevoke() {
        stopTunnel()
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopTunnel()
        controlExecutor.shutdownNow()
        super.onDestroy()
    }
}
