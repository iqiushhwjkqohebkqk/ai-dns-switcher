package ru.aidnsswitcher.app

import android.util.Log
import java.io.Closeable
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean

/**
 * A local SOCKS5 server. The tun2socks engine connects to 127.0.0.1; this server
 * opens ordinary, protected sockets on the device's underlying network.
 * DNS on UDP/TCP port 53 is resolved through the selected Smart-DNS DoH profile.
 */
class LocalSocks5Server(
    private val protectSocket: (Socket) -> Boolean,
    private val protectDatagram: (DatagramSocket) -> Boolean,
    private val resolveDns: (ByteArray) -> ByteArray,
    private val onFatalError: (Throwable) -> Unit,
    private val username: String,
    private val password: String,
    private val port: Int = 1080
) : Closeable {
    companion object { private const val TAG = "AiDnsSocks5" }

    private val running = AtomicBoolean(false)
    private val workers = ThreadPoolExecutor(
        4, 16, 60L, TimeUnit.SECONDS, LinkedBlockingQueue(256),
        { task -> Thread(task, "ai-dns-socks-worker").apply { isDaemon = true } },
        ThreadPoolExecutor.AbortPolicy()
    )
    private var server: ServerSocket? = null
    @Volatile var boundPort: Int = 0
        private set
    private val clients = CopyOnWriteArraySet<Socket>()
    private val upstreamSockets = CopyOnWriteArraySet<Socket>()
    private var acceptThread: Thread? = null

    fun start() {
        check(running.compareAndSet(false, true)) { "SOCKS5 server already started" }
        try {
            val socket = ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), port), 64)
            }
            server = socket
            boundPort = socket.localPort
            acceptThread = Thread({ acceptLoop(socket) }, "ai-dns-socks-accept").apply {
                isDaemon = true
                start()
            }
        } catch (t: Throwable) {
            running.set(false)
            throw t
        }
    }

    private fun acceptLoop(listener: ServerSocket) {
        while (running.get()) {
            try {
                val client = listener.accept()
                client.tcpNoDelay = true
                client.soTimeout = 15_000
                clients.add(client)
                try {
                    workers.execute { handleClient(client) }
                } catch (e: RejectedExecutionException) {
                    clients.remove(client)
                    runCatching { client.close() }
                }
            } catch (e: SocketException) {
                if (running.get()) onFatalError(e)
                return
            } catch (e: Throwable) {
                if (running.get()) Log.w(TAG, "SOCKS5 accept failed", e)
            }
        }
    }

    private fun handleClient(client: Socket) {
        try { client.use { socket ->
            val input = DataInputStream(socket.getInputStream())
            val output = DataOutputStream(socket.getOutputStream())
            try {
                // Greeting: require RFC 1929 authentication before accepting local relay commands.
                if (input.readUnsignedByte() != 5) return
                val methodCount = input.readUnsignedByte()
                val methods = ByteArray(methodCount)
                input.readFully(methods)
                if (2.toByte() !in methods) {
                    output.write(byteArrayOf(5, 0xff.toByte())); output.flush(); return
                }
                output.write(byteArrayOf(5, 2)); output.flush()

                // RFC 1929 username/password authentication. The listener is loopback-only;
                // the per-run random secret also prevents other local apps using it as a proxy.
                if (input.readUnsignedByte() != 1) return
                val userLength = input.readUnsignedByte()
                val user = ByteArray(userLength).also(input::readFully)
                val passLength = input.readUnsignedByte()
                val pass = ByteArray(passLength).also(input::readFully)
                val userOk = java.security.MessageDigest.isEqual(user, username.toByteArray(Charsets.UTF_8))
                val passOk = java.security.MessageDigest.isEqual(pass, password.toByteArray(Charsets.UTF_8))
                if (!userOk || !passOk) {
                    output.write(byteArrayOf(1, 1)); output.flush(); return
                }
                output.write(byteArrayOf(1, 0)); output.flush()

                if (input.readUnsignedByte() != 5) return
                val command = input.readUnsignedByte()
                if (input.readUnsignedByte() != 0) { writeReply(output, 1); return }
                val target = readTarget(input) ?: run { writeReply(output, 8); return }
                when (command) {
                    1 -> if (target.port == 0) writeReply(output, 8) else handleConnect(socket, input, output, target)
                    3 -> handleUdpAssociate(socket, input, output)
                    else -> writeReply(output, 7)
                }
            } catch (_: EOFException) {
                // Normal client disconnect.
            } catch (e: Throwable) {
                if (running.get()) Log.d(TAG, "SOCKS5 client closed", e)
            }
        } } finally { clients.remove(client) }
    }

    private data class Target(val host: String, val port: Int)

    private fun readTarget(input: DataInputStream): Target? {
        val atyp = input.readUnsignedByte()
        val host = when (atyp) {
            1 -> ByteArray(4).also(input::readFully).let { InetAddress.getByAddress(it).hostAddress }
            3 -> {
                val size = input.readUnsignedByte()
                if (size == 0) return null
                ByteArray(size).also(input::readFully).toString(Charsets.US_ASCII)
            }
            4 -> ByteArray(16).also(input::readFully).let { InetAddress.getByAddress(it).hostAddress }
            else -> return null
        }
        val targetPort = input.readUnsignedShort()
        return Target(host, targetPort)
    }

    private fun handleConnect(client: Socket, input: DataInputStream, output: DataOutputStream, target: Target) {
        if (target.port == 53) {
            client.soTimeout = 0
            writeReply(output, 0)
            handleTcpDns(input, output)
            return
        }

        val upstream = Socket()
        upstreamSockets.add(upstream)
        try {
            if (!protectSocket(upstream)) throw IOException("VpnService.protect(Socket) returned false")
            upstream.connect(InetSocketAddress(target.host, target.port), 10_000)
            upstream.tcpNoDelay = true
            client.soTimeout = 0
            writeReply(output, 0)
            bridgeTcp(client, upstream)
        } catch (e: Throwable) {
            runCatching { upstream.close() }
            runCatching { writeReply(output, 5) }
            Log.d(TAG, "SOCKS5 CONNECT ${target.host}:${target.port} failed", e)
        } finally {
            upstreamSockets.remove(upstream)
        }
    }

    private fun handleTcpDns(input: DataInputStream, output: DataOutputStream) {
        while (running.get()) {
            val length = try { input.readUnsignedShort() } catch (_: EOFException) { return }
            if (length !in 12..8192) throw IOException("Invalid TCP DNS frame length: $length")
            val query = ByteArray(length)
            input.readFully(query)
            val response = try {
                resolveDns(query)
            } catch (e: Throwable) {
                Log.w(TAG, "TCP DNS through DoH failed", e)
                DnsPacketCodec.makeServFail(query) ?: throw e
            }
            require(response.size in 12..8192) { "Invalid DoH response size" }
            output.writeShort(response.size)
            output.write(response)
            output.flush()
        }
    }

    private fun bridgeTcp(client: Socket, upstream: Socket) {
        val leftToRight = Thread({
            runCatching { client.getInputStream().copyTo(upstream.getOutputStream()) }
            runCatching { upstream.shutdownOutput() }
        }, "ai-dns-socks-up").apply { isDaemon = true }
        val rightToLeft = Thread({
            runCatching { upstream.getInputStream().copyTo(client.getOutputStream()) }
            runCatching { client.shutdownOutput() }
        }, "ai-dns-socks-down").apply { isDaemon = true }
        leftToRight.start(); rightToLeft.start()
        try { leftToRight.join(); rightToLeft.join() } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        } finally {
            runCatching { upstream.close() }
        }
    }

    private fun handleUdpAssociate(client: Socket, input: DataInputStream, output: DataOutputStream) {
        val association = UdpAssociation()
        try {
            association.start()
            client.soTimeout = 0
            val address = InetAddress.getByName("127.0.0.1").address
            val portBytes = byteArrayOf((association.localPort ushr 8).toByte(), association.localPort.toByte())
            output.write(byteArrayOf(5, 0, 0, 1) + address + portBytes)
            output.flush()
            // The SOCKS control connection must remain open for the UDP association lifetime.
            while (running.get() && input.read() != -1) { /* control channel only */ }
        } finally {
            association.close()
        }
    }

    private inner class UdpAssociation : Closeable {
        private val active = AtomicBoolean(false)
        private lateinit var relay: DatagramSocket
        private val outbound = ConcurrentHashMap<String, DatagramSocket>()
        @Volatile private var lastClient: InetSocketAddress? = null
        val localPort: Int get() = relay.localPort

        fun start() {
            relay = DatagramSocket(null).apply {
                reuseAddress = true
                bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0))
            }
            if (!protectDatagram(relay)) {
                relay.close()
                throw IOException("VpnService.protect(DatagramSocket) returned false")
            }
            relay.soTimeout = 1000
            active.set(true)
            Thread({ receiveLoop() }, "ai-dns-socks-udp-relay").apply { isDaemon = true; start() }
        }

        private fun receiveLoop() {
            val buffer = ByteArray(65507)
            while (running.get() && active.get()) {
                try {
                    val packet = DatagramPacket(buffer, buffer.size)
                    relay.receive(packet)
                    val replyTarget = InetSocketAddress(packet.address, packet.port)
                    lastClient = replyTarget
                    val request = Socks5UdpCodec.parse(packet.data, packet.length) ?: continue
                    if (request.port == 53) {
                        workers.execute {
                            val response = try { resolveDns(request.payload) }
                            catch (e: Throwable) {
                                Log.w(TAG, "UDP DNS through DoH failed", e)
                                DnsPacketCodec.makeServFail(request.payload)
                            }
                            if (response != null && active.get()) sendToClient(
                                Socks5UdpCodec.responseForRequest(request, response), replyTarget
                            )
                        }
                    } else {
                        sendToDestination(request)
                    }
                } catch (_: SocketTimeoutException) {
                    // Allows a timely close check.
                } catch (e: SocketException) {
                    if (active.get()) Log.d(TAG, "UDP relay socket closed", e)
                    return
                } catch (e: Throwable) {
                    if (active.get()) Log.w(TAG, "UDP relay packet failed", e)
                }
            }
        }

        private fun sendToDestination(request: Socks5UdpCodec.DatagramRequest) {
            val key = "${request.host}:${request.port}"
            if (!outbound.containsKey(key) && outbound.size >= 128) return
            val destination = InetSocketAddress(request.host, request.port)
            val socket = outbound[key] ?: createOutboundSocket(destination, key)?.let { created ->
                outbound.putIfAbsent(key, created)?.also { created.close() } ?: created
            } ?: return
            runCatching { socket.send(DatagramPacket(request.payload, request.payload.size, destination)) }
                .onFailure { Log.d(TAG, "UDP send to $key failed", it) }
        }

        private fun createOutboundSocket(destination: InetSocketAddress, key: String): DatagramSocket? {
            return runCatching {
                val bindAddress = if (destination.address is java.net.Inet6Address) {
                    InetAddress.getByName("::")
                } else InetAddress.getByName("0.0.0.0")
                DatagramSocket(null).apply {
                    bind(InetSocketAddress(bindAddress, 0))
                    if (!protectDatagram(this)) {
                        close()
                        throw IOException("VpnService.protect(UDP) returned false")
                    }
                    soTimeout = 1000
                }
            }.onFailure { Log.d(TAG, "Cannot open UDP socket", it) }.getOrNull()?.also { socket ->
                Thread({ udpResponseLoop(socket, key) }, "ai-dns-socks-udp-upstream").apply { isDaemon = true; start() }
            }
        }

        private fun udpResponseLoop(socket: DatagramSocket, key: String) {
            val buffer = ByteArray(65507)
            var idleSince = System.currentTimeMillis()
            try {
                while (active.get() && !socket.isClosed) {
                    try {
                        val packet = DatagramPacket(buffer, buffer.size)
                        socket.receive(packet)
                        idleSince = System.currentTimeMillis()
                        val target = lastClient ?: continue
                        val frame = Socks5UdpCodec.responseFrom(packet.address, packet.port,
                            packet.data.copyOfRange(packet.offset, packet.offset + packet.length))
                        sendToClient(frame, target)
                    } catch (_: SocketTimeoutException) {
                        if (System.currentTimeMillis() - idleSince > 60_000) return
                    }
                }
            } catch (e: SocketException) {
                if (active.get()) Log.d(TAG, "UDP upstream socket closed", e)
            } finally {
                outbound.remove(key, socket)
                runCatching { socket.close() }
            }
        }

        private fun sendToClient(data: ByteArray, target: InetSocketAddress) {
            if (!active.get() || relay.isClosed) return
            runCatching { relay.send(DatagramPacket(data, data.size, target)) }
                .onFailure { Log.d(TAG, "UDP reply failed", it) }
        }

        override fun close() {
            if (!active.compareAndSet(true, false)) return
            runCatching { relay.close() }
            outbound.values.forEach { runCatching { it.close() } }
            outbound.clear()
        }
    }

    private fun writeReply(output: DataOutputStream, status: Int) {
        output.write(byteArrayOf(5, status.toByte(), 0, 1, 0, 0, 0, 0, 0, 0))
        output.flush()
    }

    override fun close() {
        if (!running.compareAndSet(true, false)) return
        runCatching { server?.close() }
        server = null
        clients.forEach { runCatching { it.close() } }
        clients.clear()
        upstreamSockets.forEach { runCatching { it.close() } }
        upstreamSockets.clear()
        workers.shutdownNow()
        acceptThread?.interrupt()
        acceptThread = null
    }
}
