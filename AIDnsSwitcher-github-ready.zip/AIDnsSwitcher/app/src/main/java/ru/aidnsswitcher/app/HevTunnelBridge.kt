package ru.aidnsswitcher.app

import java.lang.reflect.InvocationTargetException

/** Reflection wrapper keeps source compilation independent from the native AAR's Java binding. */
object HevTunnelBridge {
    private const val BINDING_CLASS = "hev.htproxy.TProxyService"

    private fun invoke(method: String, vararg args: Any): Any? {
        try {
            val type = Class.forName(BINDING_CLASS)
            val parameterTypes = when (method) {
                "TProxyStartService" -> arrayOf(String::class.java, Integer.TYPE)
                else -> emptyArray()
            }
            return type.getMethod(method, *parameterTypes).invoke(null, *args)
        } catch (e: InvocationTargetException) {
            throw (e.targetException ?: e)
        }
    }

    fun start(configPath: String, tunFd: Int): Boolean =
        invoke("TProxyStartService", configPath, tunFd) as? Boolean ?: false

    fun stop(): Boolean = invoke("TProxyStopService") as? Boolean ?: false

    fun isRunning(): Boolean = invoke("TProxyIsRunning") as? Boolean ?: false

    fun stats(): LongArray = invoke("TProxyGetStats") as? LongArray ?: longArrayOf()
}
