package ru.aidnsswitcher.app

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

object DnsProbe {
    private val ids = AtomicInteger(1000)

    fun checkProfile(profile: DnsProfile, service: Pair<String, String>): ProbeResult {
        val (name, host) = service
        return try {
            val addresses = queryA(profile.dohUrl, host)
            if (addresses.isEmpty()) {
                ProbeResult(name, "DNS: у домена нет IPv4-ответа", false)
            } else {
                val code = httpsProbe(profile.dohUrl, host, addresses)
                when (code) {
                    in 200..399 -> ProbeResult(name, "Доступен · HTTP $code · ${addresses.first()}", true)
                    in 400..499 -> ProbeResult(name, "Сервер отвечает, но доступ ограничен · HTTP $code", false)
                    else -> ProbeResult(name, "Сервер вернул HTTP $code", false)
                }
            }
        } catch (e: Exception) {
            ProbeResult(name, "Ошибка: ${e.message ?: e.javaClass.simpleName}", false)
        }
    }

    fun queryA(endpoint: String, host: String): List<String> {
        val id = ids.incrementAndGet() and 0xffff
        val requestBody = buildAQuery(id, host)
        val request = Request.Builder()
            .url(endpoint)
            .post(requestBody.toRequestBody("application/dns-message".toMediaType()))
            .header("Accept", "application/dns-message")
            .header("User-Agent", "AI-DNS-Switcher/0.4.9")
            .build()

        DnsBootstrap.client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("DoH HTTP ${response.code}")
            val body = response.body?.bytes() ?: error("Пустой DNS-ответ")
            return parseAResponse(body, id)
        }
    }

    private fun buildAQuery(id: Int, host: String): ByteArray {
        val out = ByteArrayOutputStream()
        fun write16(value: Int) { out.write((value ushr 8) and 0xff); out.write(value and 0xff) }
        write16(id)
        write16(0x0100) // recursion desired
        write16(1); write16(0); write16(0); write16(0)
        host.trimEnd('.').split('.').forEach { label ->
            val bytes = label.toByteArray(Charsets.US_ASCII)
            require(bytes.isNotEmpty() && bytes.size <= 63) { "Некорректное доменное имя" }
            out.write(bytes.size)
            out.write(bytes)
        }
        out.write(0)
        write16(1) // A
        write16(1) // IN
        return out.toByteArray()
    }

    private fun parseAResponse(data: ByteArray, expectedId: Int): List<String> {
        require(data.size >= 12) { "Короткий DNS-ответ" }
        fun u16(pos: Int) = ((data[pos].toInt() and 0xff) shl 8) or (data[pos + 1].toInt() and 0xff)
        require(u16(0) == expectedId) { "ID DNS-ответа не совпадает" }
        val flags = u16(2)
        require((flags and 0x8000) != 0) { "Получен не DNS-ответ" }
        val rcode = flags and 0x0f
        require(rcode == 0) { "DNS RCODE=$rcode" }
        val questionCount = u16(4)
        val answerCount = u16(6)
        var position = 12

        repeat(questionCount) {
            position = skipName(data, position)
            require(position + 4 <= data.size) { "Повреждённый DNS question" }
            position += 4
        }

        val addresses = mutableListOf<String>()
        repeat(answerCount) {
            position = skipName(data, position)
            require(position + 10 <= data.size) { "Повреждённая DNS-запись" }
            val type = u16(position)
            val clazz = u16(position + 2)
            val dataLength = u16(position + 8)
            position += 10
            require(position + dataLength <= data.size) { "Обрезанная DNS-запись" }
            if (type == 1 && clazz == 1 && dataLength == 4) {
                addresses += (0 until 4).joinToString(".") { (data[position + it].toInt() and 0xff).toString() }
            }
            position += dataLength
        }
        return addresses.distinct()
    }

    private fun skipName(data: ByteArray, start: Int): Int {
        var position = start
        while (position < data.size) {
            val length = data[position].toInt() and 0xff
            if (length == 0) return position + 1
            if ((length and 0xc0) == 0xc0) {
                require(position + 1 < data.size) { "Повреждённый DNS pointer" }
                return position + 2
            }
            require(length <= 63 && position + 1 + length <= data.size) { "Повреждённое DNS-имя" }
            position += 1 + length
        }
        error("Обрезанное DNS-имя")
    }

    private fun httpsProbe(dohUrl: String, host: String, knownAddresses: List<String>): Int {
        val client = OkHttpClient.Builder()
            .connectTimeout(4500, TimeUnit.MILLISECONDS)
            .readTimeout(4500, TimeUnit.MILLISECONDS)
            .callTimeout(7000, TimeUnit.MILLISECONDS)
            .dns { requestedHost ->
                val ips = if (requestedHost.equals(host, ignoreCase = true)) {
                    knownAddresses
                } else {
                    queryA(dohUrl, requestedHost)
                }
                if (ips.isEmpty()) throw UnknownHostException("Нет A-записи для $requestedHost")
                ips.map { InetAddress.getByName(it) }
            }
            .followRedirects(true)
            .build()
        val request = Request.Builder()
            .url("https://$host/")
            .header("User-Agent", "AI-DNS-Switcher/0.4.9")
            .get()
            .build()
        client.newCall(request).execute().use { return it.code }
    }
}
