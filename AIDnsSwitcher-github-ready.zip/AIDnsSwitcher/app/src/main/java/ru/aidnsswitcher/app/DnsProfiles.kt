package ru.aidnsswitcher.app

data class DnsProfile(
    val id: String,
    val name: String,
    val dohUrl: String,
    val note: String
)

object DnsProfiles {
    // Public endpoints reported by the providers/community documentation.
    // Availability is always checked at runtime; these values can change.
    val builtIn = listOf(
        DnsProfile(
            id = "geohide",
            name = "GeoHide",
            dohUrl = "https://geohide.ru/dns-query",
            note = "Геоблокировки · основной адрес · DoH"
        ),
        DnsProfile(
            id = "geohide-eu",
            name = "GeoHide EU",
            dohUrl = "https://eu.geohide.ru/dns-query",
            note = "Европейский регион · DoH"
        ),
        DnsProfile(
            id = "geohide-us",
            name = "GeoHide US",
            dohUrl = "https://us.geohide.ru/dns-query",
            note = "Регион США · DoH"
        ),
        DnsProfile(
            id = "geohide-dns",
            name = "GeoHide DNS",
            dohUrl = "https://dns.geohide.ru/dns-query",
            note = "Дополнительный адрес · DoH"
        ),
        DnsProfile(
            id = "comss",
            name = "Comss.one",
            dohUrl = "https://dns.comss.one/dns-query",
            note = "Альтернативный профиль · DoH"
        )
    )
}

data class AiApp(
    val packageName: String,
    val label: String,
    val installed: Boolean = true
)

data class ProbeResult(val service: String, val detail: String, val ok: Boolean)
