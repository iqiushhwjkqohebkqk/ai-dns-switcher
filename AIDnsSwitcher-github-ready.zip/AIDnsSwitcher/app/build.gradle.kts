import java.net.URL
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val nativeVersion = "2.19.3"
val nativeAar = layout.projectDirectory.file("libs/hev-socks5-tunnel.aar")
val nativeAarSha256 = "ab6c581e6157680cfe5687ee7bbdcf95405c006c2db3701879ec44b9e5f83836"
val nativeAarUrl = "https://github.com/heiher/hev-socks5-tunnel/releases/download/$nativeVersion/hev-socks5-tunnel.aar"

val fetchHevTunnelAar by tasks.registering {
    inputs.property("nativeVersion", nativeVersion)
    inputs.property("nativeSha256", nativeAarSha256)
    outputs.file(nativeAar)
    outputs.upToDateWhen { false }
    doLast {
        val destination = nativeAar.asFile
        destination.parentFile.mkdirs()
        fun sha256(file: java.io.File): String = MessageDigest.getInstance("SHA-256")
            .digest(file.readBytes()).joinToString("") { "%02x".format(it) }

        if (destination.exists() && sha256(destination) == nativeAarSha256) return@doLast
        val temporary = destination.resolveSibling(destination.name + ".download")
        temporary.delete()
        URL(nativeAarUrl).openConnection().apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            setRequestProperty("User-Agent", "AI-DNS-Switcher-Android-Build")
        }.getInputStream().use { input -> temporary.outputStream().use { output -> input.copyTo(output) } }
        val actual = sha256(temporary)
        check(actual == nativeAarSha256) {
            "Hev AAR checksum mismatch: expected $nativeAarSha256, got $actual"
        }
        if (destination.exists()) destination.delete()
        check(temporary.renameTo(destination)) { "Could not move native AAR into libs/" }
    }
}

tasks.named("preBuild").configure { dependsOn(fetchHevTunnelAar) }

android {
    namespace = "ru.aidnsswitcher.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.aidnsswitcher.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 14
        versionName = "0.4.9"
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation(files(nativeAar).builtBy(fetchHevTunnelAar))
    testImplementation("junit:junit:4.13.2")
}
